#include <vector>
#include <string>
#include <iostream>
#include "table.h"
#include "tuple.h"

using namespace std;

int main()
{
  cout << "Enter any character to terminate program: \n";
  char c;
  cin >> c;
}



